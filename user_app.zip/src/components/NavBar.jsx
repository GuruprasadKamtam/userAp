import React from 'react'

const NavBar = () => {
  return (
    <>
         
    </>
  )
}

export default NavBar
